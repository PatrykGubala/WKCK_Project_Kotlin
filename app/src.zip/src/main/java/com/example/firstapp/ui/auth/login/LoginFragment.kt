package com.example.firstapp.ui.auth.login

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.firstapp.R
import com.example.firstapp.databinding.FragmentSignInBinding // Import the binding class
import com.example.firstapp.ui.BaseFragment

import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth

class LoginFragment : BaseFragment() {

    private lateinit var binding: FragmentSignInBinding // Declare a binding variable

    private val fbAuth = FirebaseAuth.getInstance()
    private val LOG_DEBUG = "LOG_DEBUG"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout and obtain an instance of the binding class
        binding = FragmentSignInBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Access views using the binding variable
        binding.apply {
            setupLoginClick()
            setupRegistrationClick()
        }
    }

    private fun setupRegistrationClick() {

    }

    private fun setupLoginClick() {
        binding.loginButton.setOnClickListener {
            val email = binding.emailLoginInput.text?.trim().toString()
            val pass = binding.passLoginInput.text?.trim().toString()

            fbAuth.signInWithEmailAndPassword(email, pass)
                .addOnSuccessListener { authRes ->
                    if(authRes.user != null) startApp()
                }
                .addOnFailureListener{ exc ->
                    Snackbar.make(requireView(), "Upss...Something went wrong...", Snackbar.LENGTH_SHORT)
                        .show()
                    Log.d(LOG_DEBUG, exc.message.toString())
                }
        }
    }
}
