package com.revolshen.firebaseseriesmini.data

import java.lang.Exception
import kotlin.jvm.Throws

data class Car (val id: String? = null,
                val name: String? = null,
                val image: String? = null ,
                val productionYear: String? = null)