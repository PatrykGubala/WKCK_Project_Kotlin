package com.example.firstapp.ui.auth.register

import androidx.lifecycle.ViewModel

class RegisterViewModel: ViewModel() {


}