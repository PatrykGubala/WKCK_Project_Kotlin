package com.example.firstapp.ui.auth.login

import androidx.lifecycle.ViewModel

class LoginViewModel : ViewModel() {
}